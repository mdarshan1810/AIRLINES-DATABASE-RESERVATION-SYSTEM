
<link rel="stylesheet" href="CSS/about_us.css" type="text/css">
<div class="about-section">
  <h1>About Us</h1>
  <p>Some text about who we are and what we do.</p>
  <p>We are here guide you in any issues that you face.</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>Team member 1</h2>
        <p class="title">Team member 1</p>
        <p>+91 7010212186</p>
        <p>team1@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

<div class="row">
  <div class="column">
    <div class="card"> 
        <div class="container">
        <h2>Team member 2</h2>
        <p class="title">Team member 2</p>
        <p>+91 9980223454</p>
        <p>team2@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

